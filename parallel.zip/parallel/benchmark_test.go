package main

import (
	"fmt"
	"io/ioutil"
	"strconv"
	"strings"
	"testing"
	"uk.ac.bris.cs/gameoflife/gol"
	"uk.ac.bris.cs/gameoflife/util"
)

func BenchmarkExecuteTurns(b *testing.B) {
	tests := []gol.Params{
		{ImageWidth: 16, ImageHeight: 16},
		{ImageWidth: 64, ImageHeight: 64},
		{ImageWidth: 512, ImageHeight: 512},
	}

	events := make(chan gol.Event)

	c := gol.DistributorChannels{
		KeyPresses: nil,
		Events:     events,
		IoCommand:  nil,
		IoIdle:     nil,
		IoFilename: nil,
		IoOutput:   nil,
		IoInput:    nil,
	}

	// Will run 1, 10, 100 turns on 16x16, 64x64, 512x512 for 1-16 threads
	for _, p := range tests {
		testWorld := generateTestWorld(p.ImageHeight)
		for _, turn := range []int{50, 100, 150} {
			p.Turns = turn
			for threads := 1; threads <= 16; threads++ {
				p.Threads = threads
				//Run a sub benchmark for each benchmark.
				b.Run(fmt.Sprintf("mapsize-%d_turns-%d_workers-%d", p.ImageHeight, p.Turns,threads), func(b *testing.B) {
					for i := 0; i < b.N; i++ {
						gol.ExecuteTurns(p.Turns, testWorld, p, c)
					}
				})
			}
		}
	}
}

// Generate a test world with the specific size
func generateTestWorld(size int) [][]byte{
	world := make([][]byte, size)
	for x := 0; x < size; x++ {
		world[x] = make([]byte, size)
	}

	filename := strconv.Itoa(size) + "x" + strconv.Itoa(size)
	data, ioError := ioutil.ReadFile("images/" + filename + ".pgm")
	util.Check(ioError)
	fields := strings.Fields(string(data))
	image := []byte(fields[4])

	x := 0
	y := 0

	for _, b := range image {
		world[y][x] = b
		if x == size - 1 && y != size - 1{
			x = 0
			y++
		} else if x != size-1{
			x++
		}
	}
	return world
}