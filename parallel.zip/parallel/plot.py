import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Read in the saved CSV data.
benchmark_data = pd.read_csv('results.csv', header=0, names=['name', 'time', 'range'])
# Go stores benchmark results in nanoseconds. Convert all results to seconds.
benchmark_data['time'] /= 1e+9

# Use the name of the benchmark to extract the number of worker threads used.
#  e.g. "ExecuteTurns/16-8" used 16 worker threads (goroutines).
# Note how the benchmark name corresponds to the regular expression 'ExecuteTurns/\d+_workers-\d+'.
# Also note how we place brackets around the value we want to extract.
benchmark_data['threads'] = benchmark_data['name'].str.extract('\d+_workers-(\d+)').apply(pd.to_numeric)
benchmark_data['mapsize'] = benchmark_data['name'].str.extract('mapsize-(\d+)').apply(pd.to_numeric)
benchmark_data['turns'] = benchmark_data['name'].str.extract('\d+_turns-(\d+)').apply(pd.to_numeric)

#every 16 is a new turnCount
for i in range(9):
  mapSize = (benchmark_data['mapsize'][i * 16])
  turns = (benchmark_data['turns'][i*16])
  threads = (benchmark_data['threads'][i*16])
  time = (benchmark_data['time'][i*16])
  plt.title('Size: ' + str(mapSize) + ', Turns : ' + str(turns))
  ax = sns.barplot(data=benchmark_data, x='threads', y='time')
  ax.set(xlabel='Worker threads used', ylabel='Time taken (s)')
  plt.show()