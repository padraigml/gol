package gol

import (
	"github.com/veandco/go-sdl2/sdl"
	"os"
	"strconv"
	"time"
	"uk.ac.bris.cs/gameoflife/util"
)

type DistributorChannels struct {
	KeyPresses <- chan rune
	Events    chan<- Event
	IoCommand  chan<- ioCommand
	IoIdle     <-chan bool
	IoFilename chan<- string
	IoOutput chan<- uint8
	IoInput  <-chan uint8
}

type Info struct {
	startY int
	endY int
	turn int
	world [][]byte
	c DistributorChannels
	p Params
}

var paused bool
var countingCells bool

// A GOLworker calculates the next state of the game of life board only between the given coordinates (startY, endY)
// and sends the result of that calculation down the "out" channel

func GOLworker(info Info, out chan<- [][]byte) {
	res := CalculateNextState(info)
	out <- res
}

// CalculateNextState -- Function to calculate the next state of the game, within the given Y bounds.
func CalculateNextState(info Info) [][]byte {
	imgHeight := info.p.ImageHeight
	imgWidth := info.p.ImageWidth
	world := info.world
	// Create an empty world to store the result in.
	nw := make([][]byte, info.p.ImageHeight)
	for x := 0; x < info.p.ImageHeight; x++ {
		nw[x] = make([]byte, info.p.ImageWidth)
	}

	// Loop through the world between the given bounds
	for y :=  info.startY; y < info.endY; y++ {
		for x := 0; x < info.p.ImageWidth; x++ {
			// Calculate the number of alive neighbours for each cell.
			alive := (world[(y+imgHeight-1)%imgHeight][(x+imgWidth-1)%imgWidth] / 255) +
				(world[(y+imgHeight-1)%imgHeight][(x+imgWidth)%imgWidth] / 255) +
				(world[(y+imgHeight-1)%imgHeight][(x+imgWidth+1)%imgWidth] / 255) +
				(world[(y+imgHeight)%imgHeight][(x+imgWidth-1)%imgWidth] / 255) +
				(world[(y+imgHeight)%imgHeight][(x+imgWidth+1)%imgWidth] / 255) +
				(world[(y+imgHeight+1)%imgHeight][(x+imgWidth-1)%imgWidth] / 255) +
				(world[(y+imgHeight+1)%imgHeight][(x+imgWidth)%imgWidth] / 255) +
				(world[(y+imgHeight+1)%imgHeight][(x+imgWidth+1)%imgWidth] / 255)
			if world[y][x] == 255 {
				if alive < 2 || alive > 3{
					nw[y][x] = 0
					info.c.Events <- CellFlipped{CompletedTurns: info.turn, Cell: util.Cell{Y: y, X: x}}
				}
				if alive == 2 || alive == 3 {
					nw[y][x] = 255
				}
			}
			if world[y][x] == 0 && alive == 3{
				nw[y][x] = 255
				info.c.Events <- CellFlipped{CompletedTurns: info.turn, Cell: util.Cell{Y: y, X: x}}
			}
		}
	}
	return nw[info.startY:info.endY]
}

// Distributor divides the work between workers and interacts with other goroutines.
func Distributor(p Params, c DistributorChannels) {
	filename := strconv.Itoa(p.ImageWidth) + "x" + strconv.Itoa(p.ImageHeight)
	world := make([][]byte, p.ImageHeight)
	for x := 0; x < p.ImageHeight; x++ {
		world[x] = make([]byte, p.ImageWidth)
	}

	c.IoCommand <- ioInput
	c.IoFilename <- filename

	x := 0
	y := 0

	// Load the file into world.
	for b := range c.IoInput {
		world[y][x] = b
		if b == 255 {
			c.Events <- CellFlipped{CompletedTurns: 0, Cell: util.Cell{Y: y, X: x}}
		}
		if x == p.ImageWidth - 1 && y != p.ImageHeight - 1{
			x = 0
			y++
		} else if x != p.ImageWidth-1{
			x++
		}
	}

	ticker := time.NewTicker(2 * time.Second)
	paused = false
	countingCells = false

	go func() {
		for range ticker.C {
			countingCells = true
		}
	}()

	ExecuteTurns(p.Turns, world, p, c)

	// Report the final state using FinalTurnCompleteEvent.
	c.Events <- FinalTurnComplete{CompletedTurns: p.Turns, Alive: calculateAliveCells(p, world)}


	file := generateOutput(p, world, c)
	c.Events <- ImageOutputComplete{
		CompletedTurns: p.Turns,
		Filename:       file,
	}

	// Make sure that the Io has finished any output before exiting.
	c.IoCommand <- ioCheckIdle
	<-c.IoIdle

	c.Events <- StateChange{p.Turns, Quitting}

	ticker.Stop()
	// Close the channel to stop the SDL goroutine gracefully. Removing may cause deadlock.
	close(c.Events)
}

func ExecuteTurns(turnCount int, world [][]byte, p Params, c DistributorChannels) [][]byte{

	info := Info{
		startY: 0,
		endY:   0,
		turn:   0,
		world:  world,
		c:      c,
		p:      p,
	}

	for turn := 0; turn < turnCount; turn++ {
		info.turn = turn
		for {
			if !paused {
				break
			}
		}
		for {
			if !countingCells {
				break
			} else {
				c.Events <- AliveCellsCount{CompletedTurns: turn, CellsCount: numAliveCells(p, world)}
				countingCells = false
			}
		}

		// Anonymous goroutine to detect keypresses.
		go func() {
			key := <-c.KeyPresses
			if key == sdl.K_p {
				if paused {
					paused = false
					c.Events <- StateChange{CompletedTurns: turn, NewState: Executing}

				} else {
					paused = true
					c.Events <- StateChange{CompletedTurns: turn, NewState: Paused}
				}
			}
			if key == sdl.K_s {
				file := generateOutput(p, world, c)
				c.Events <- ImageOutputComplete{
					CompletedTurns: turn,
					Filename:       file,
				}
			}
			if key == sdl.K_q {
				paused = true
				file := generateOutput(p, world, c)
				c.Events <- ImageOutputComplete{
					CompletedTurns: turn,
					Filename:       file,
				}
				c.Events <- StateChange{turn, Quitting}
				time.Sleep(2 * time.Second)
				os.Exit(0)
			}
		}()

		var cs []chan [][]byte
		cs = make([]chan [][]byte, p.Threads)
		var newWorldData [][]byte
		// If the world doesn't divide equally then we want to iterate to threads-1 and then the last worker
		// gets more of the world than the others.
		var t int
		diff := p.ImageHeight % p.Threads
		if diff == 0 {
			t = p.Threads
		} else {
			t = p.Threads-1
		}

		if p.Threads == 1 {
			info.endY = p.ImageHeight
			newWorldData = CalculateNextState(info)
		} else if p.Threads > 1 {
			sHeight := p.ImageHeight / p.Threads
			for i := 0; i < t; i++ {
				cs[i] = make(chan [][]byte)
				info.startY = i*sHeight
				info.endY = (i+1)*sHeight
				go GOLworker(info, cs[i])
			}
			if t < p.Threads {
				cs[t] = make(chan [][]byte)
				info.startY = t*sHeight
				info.endY = (p.Threads)*sHeight+diff
				go GOLworker(info, cs[t])
			}
			for j := 0; j < len(cs); j++ {
				part := <-cs[j]
				newWorldData = append(newWorldData, part...)
			}
		}

		copy(world, newWorldData)
		c.Events <- TurnComplete{CompletedTurns: turn}
	}
	return world
}

// Function to calculate the alive cells on the board
func calculateAliveCells(p Params, world [][]byte) []util.Cell {
	var c []util.Cell
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			if world[y][x] == 255 {
				n := util.Cell{X: x, Y: y}
				c = append(c, n)
			}
		}
	}

	return c
}

// Function to tell the io goroutine to generate an output PGM based on the current state of the board.
func generateOutput(p Params, world [][]byte, c DistributorChannels) string {
	c.IoCommand <- ioOutput
	file := strconv.Itoa(p.ImageWidth) + "x" + strconv.Itoa(p.ImageHeight) + "x" + strconv.Itoa(p.Turns)
	c.IoFilename <- file
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			c.IoOutput <- world[y][x]
		}
	}
	return file
}

// Get the number of alive cells on the board
// (I could have used len(calculateAliveCells) but decided
// to make it its own function for readability
func numAliveCells(p Params, world [][]byte) int{
	count := 0
	for y := 0; y < p.ImageHeight; y++ {
		for x := 0; x < p.ImageWidth; x++ {
			if world[y][x] == 255 {
				count += 1
			}
		}
	}
	return count
}